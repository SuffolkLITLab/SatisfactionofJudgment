# Template directory

If you want to use templates for document assembly, put them in this directory.
